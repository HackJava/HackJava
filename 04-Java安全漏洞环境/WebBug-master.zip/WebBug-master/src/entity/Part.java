package entity;

public class Part {

    int all_number;
    int current_pape;
    int all_pape;
    int left;
    int right;
    int default_count;

    public int getAll_number() {
        return all_number;
    }

    public void setAll_number(int all_number) {
        this.all_number = all_number;
    }

    public int getCurrent_pape() {
        return current_pape;
    }

    public void setCurrent_pape(int current_pape) {
        this.current_pape = current_pape;
    }

    public int getAll_pape() {
        return all_pape;
    }

    public void setAll_pape(int all_pape) {
        this.all_pape = all_pape;
    }

    public int getLeft() {
        return left;
    }

    public void setLeft(int left) {
        this.left = left;
    }

    public int getRight() {
        return right;
    }

    public void setRight(int right) {
        this.right = right;
    }

    public int getDefault_count() {
        return default_count;
    }

    public void setDefault_count(int default_count) {
        this.default_count = default_count;
    }
}
