package util;

public class GlobalVariables {

    // web site title
    public static String title = "WebBug - Java漏洞靶场";

}
