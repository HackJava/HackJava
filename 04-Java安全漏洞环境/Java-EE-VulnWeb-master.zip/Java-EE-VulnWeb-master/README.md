# VulnWeb
用于演示Java Web项目中，漏洞的成因及修复方案，可用于黑盒测试和白盒测试，部分修复方案可用于生产环境。

更多：[VulnWeb又一个漏洞演示平台](http://eveino.com/180.html)