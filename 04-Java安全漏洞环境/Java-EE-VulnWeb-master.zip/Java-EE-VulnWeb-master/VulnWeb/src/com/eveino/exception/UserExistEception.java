package com.eveino.exception;

public class UserExistEception extends Exception {

	public UserExistEception(String string) {
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
