INSERT INTO ACCOUNT (accountid, name, type, ownerid) VALUES (1, 'Marvin Savings', 'Savings', 42);
INSERT INTO ACCOUNT (accountid, name, type, ownerid) VALUES (2, 'Marvin Credit Card',' Credit Card', 42);
INSERT INTO ACCOUNT (accountid, name, type, ownerid) VALUES (3, 'Zaphod Savings',' Savings', 55);
INSERT INTO ACCOUNT (accountid, name, type, ownerid) VALUES (4, 'Ford Prefect Credit Card', 'Credit Card', 10);
INSERT INTO ACCOUNT (accountid, name, type, ownerid) VALUES (5, 'Ford Prefect Savings', 'Savings', 10);