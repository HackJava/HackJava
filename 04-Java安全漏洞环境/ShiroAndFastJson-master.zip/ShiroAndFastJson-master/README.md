# ShiroAndFastJson

shiro加fastjson环境



路由：

/login 登录

/json json解析

/ser 反序列化
