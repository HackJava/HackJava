INSERT INTO customers (id, name, status, order_limit) VALUES (1, 'Arthur Dent', 'A', 10000);
INSERT INTO customers (id, name, status, order_limit) VALUES (2, 'Ford Prefect', 'B', 5000);
INSERT INTO customers (id, name, status, order_limit) VALUES (3, 'Tricia Trillian McMillan', 'C', 1000);
INSERT INTO customers (id, name, status, order_limit) VALUES (4, 'Zaphod Beeblebrox', 'D', 500);
INSERT INTO customers (id, name, status, order_limit) VALUES (5, 'Marvin', 'A', 100000);
INSERT INTO customers (id, name, status, order_limit) VALUES (6, 'Slartibartfast', 'D', 100);