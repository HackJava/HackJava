insert into contacts (username, firstname, lastname, comment) values ('userA', 'Zaphod', 'Beeblebrox', 'President');
insert into contacts (username, firstname, lastname, comment) values ('userA', 'Ford', 'Prefect', 'Researcher for the Hitchhiker''s Guide to the Galaxy');

insert into contacts (username, firstname, lastname, comment) values ('userB', 'Arthur', 'Dent', 'BBC Radio employee');
insert into contacts (username, firstname, lastname, comment) values ('userB', 'Tricia Marie', 'McMillan', '');