package de.dominikschadow.javasecurity.logging.home;

public record Login(String username, String password) {
}
