# 0x01 DeserializationTest
就是一个练习Java反序列化的最简单环境

# 0x02 自言自语
不要在意该项目,该项目没有任何意义就是作者拿来保存简单的测试环境的

# 0x03 运行方法
这是一个 java maven项目

导入idea,打开刚刚好下载好的源码

![](./images/1.png)

打开: /DeserializationTest/pom.xml 安装对应的包,第一次安装依赖包需要比较久,慢慢等不要急

![](./images/2.png)

![](./images/3.png)