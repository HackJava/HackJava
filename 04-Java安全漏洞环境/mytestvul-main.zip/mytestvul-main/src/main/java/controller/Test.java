package controller;

import java.io.File;
import java.io.IOException;

/**
 * @author: novy
 * @date: 2021/3/10
 * @time: 16:18
 **/
public class Test {
    public String document;

    public Test() {//无参构造方法
    }

    //
    public Test(String ff) { //有参
        document = ff;
//
    }
        static {
            System.out.println("123");

        }
    }