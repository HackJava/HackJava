package controller.vultest;

/**
 * @author: novy
 * @date: 2021/3/5
 * @time: 16:12
 **/
public class TestImpl {
    public String name;
    public int length;

    public void setLength(int length) {
        this.length = length;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLength() {
        return length;
    }

    public String getName() {
        return name;
    }
}
