package fastjsonvul;

public class User {
    public String name;
    public String Age;

    public void setName(String s) {
        this.name=s;
    }


    public String getName() {
        return name;

    }

    public void setAge(String s) {
        this.Age = s;
    }
}
