"# Java_deserialize_vuln_lab" 

Java反序列化漏洞学习实践中的代码

[Java反序列化漏洞学习实践一：从Serializbale接口开始，先弹个计算器](http://code2sec.com/javafan-xu-lie-hua-lou-dong-xue-xi-shi-jian-yi-cong-serializbalejie-kou-kai-shi-xian-dan-ge-ji-suan-qi.html)

[Java反序列化漏洞学习实践二：Java的反射机制（Java Reflection）](http://code2sec.com/javafan-xu-lie-hua-lou-dong-xue-xi-shi-jian-er-javade-fan-she-ji-zhi-java-reflection.html)

[Java反序列化漏洞学习实践三：理解java的动态代理机制](http://code2sec.com/javafan-xu-lie-hua-lou-dong-xue-xi-shi-jian-san-li-jie-javade-dong-tai-dai-li-ji-zhi.html)

