package Struts2;

public class s2_055 {

}
