package com.appsecco.dvja;

public class Constant {
    public static String SESSION_USER_HANDLE = "USER";
}
