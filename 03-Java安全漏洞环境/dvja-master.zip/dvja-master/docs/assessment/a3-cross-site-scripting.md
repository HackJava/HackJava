Notes:

```
Stored XSS exists in listProducts.action
The Add/Edit page can be used to inject XSS payload
This is stored in database and reflected in listProduct page
```



