package com.suyu.secexample.csrf.service;

import com.suyu.secexample.csrf.model.User;
import java.util.List;

public interface UsernameService {
    public void addUser(User user);
}
