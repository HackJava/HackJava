package com.suyu.secexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecexampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(SecexampleApplication.class, args);
    }
}
