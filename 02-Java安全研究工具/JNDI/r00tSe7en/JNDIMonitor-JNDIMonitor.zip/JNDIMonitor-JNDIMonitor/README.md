# JNDIMonitor

![](img/jndi.png)

## 简介

一个`LDAP`请求监听器，摆脱`dnslog`平台

```shell
Usage: java -jar JNDIMonitor-1.0-SNAPSHOT.jar [options]
  Options:
  * -i, --ip       Local ip address  (default: 0.0.0.0)
    -l, --ldapPort Ldap bind port (default: 1389)
    -h, --help     Show this help
```

## 参考

https://github.com/0x727/JNDIExploit/