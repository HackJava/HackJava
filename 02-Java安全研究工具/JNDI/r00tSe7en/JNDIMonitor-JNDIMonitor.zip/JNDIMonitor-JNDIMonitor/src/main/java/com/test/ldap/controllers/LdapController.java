package com.test.ldap.controllers;

public interface LdapController {
}
