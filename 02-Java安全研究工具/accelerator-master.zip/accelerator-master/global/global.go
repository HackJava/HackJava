package global

import "github.com/4ra1n/accelerator/classfile"

var CP classfile.ConstantPool
