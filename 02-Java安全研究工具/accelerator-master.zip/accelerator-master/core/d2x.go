package core

type D2F struct{ NoOperandsInstruction }

type D2I struct{ NoOperandsInstruction }

type D2L struct{ NoOperandsInstruction }
