package core

type IXOR struct{ NoOperandsInstruction }

type LXOR struct{ NoOperandsInstruction }
