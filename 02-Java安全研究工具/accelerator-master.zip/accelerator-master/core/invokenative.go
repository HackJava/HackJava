package core

type INVOKENATIVE struct{ NoOperandsInstruction }
