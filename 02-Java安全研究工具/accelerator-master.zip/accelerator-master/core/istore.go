package core

type ISTORE struct{ Index8Instruction }

type ISTORE_0 struct{ NoOperandsInstruction }

type ISTORE_1 struct{ NoOperandsInstruction }

type ISTORE_2 struct{ NoOperandsInstruction }

type ISTORE_3 struct{ NoOperandsInstruction }
