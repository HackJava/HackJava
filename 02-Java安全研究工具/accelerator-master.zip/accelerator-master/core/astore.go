package core

type ASTORE struct{ Index8Instruction }

type ASTORE_0 struct{ NoOperandsInstruction }

type ASTORE_1 struct{ NoOperandsInstruction }

type ASTORE_2 struct{ NoOperandsInstruction }

type ASTORE_3 struct{ NoOperandsInstruction }
