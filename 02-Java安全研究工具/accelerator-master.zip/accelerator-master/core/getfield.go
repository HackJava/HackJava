package core

type GET_FIELD struct{ Index16Instruction }
