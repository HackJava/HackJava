package core

type LLOAD struct{ Index8Instruction }

type LLOAD_0 struct{ NoOperandsInstruction }

type LLOAD_1 struct{ NoOperandsInstruction }

type LLOAD_2 struct{ NoOperandsInstruction }

type LLOAD_3 struct{ NoOperandsInstruction }
