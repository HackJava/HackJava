package core

type MONITORENTER struct{ NoOperandsInstruction }

type MONITOREXIT struct{ NoOperandsInstruction }
