package core

type IFNULL struct{ BranchInstruction }

type IFNONNULL struct{ BranchInstruction }
