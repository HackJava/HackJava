package core

type NEW struct{ Index16Instruction }
