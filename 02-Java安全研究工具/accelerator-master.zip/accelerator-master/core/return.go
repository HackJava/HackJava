package core

type RETURN struct{ NoOperandsInstruction }

type ARETURN struct{ NoOperandsInstruction }

type DRETURN struct{ NoOperandsInstruction }

type FRETURN struct{ NoOperandsInstruction }

type IRETURN struct{ NoOperandsInstruction }

type LRETURN struct{ NoOperandsInstruction }
