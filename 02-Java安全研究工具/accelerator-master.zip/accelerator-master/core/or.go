package core

type IOR struct{ NoOperandsInstruction }

type LOR struct{ NoOperandsInstruction }
