package core

type ARRAY_LENGTH struct{ NoOperandsInstruction }
