package core

type FLOAD struct{ Index8Instruction }

type FLOAD_0 struct{ NoOperandsInstruction }

type FLOAD_1 struct{ NoOperandsInstruction }

type FLOAD_2 struct{ NoOperandsInstruction }

type FLOAD_3 struct{ NoOperandsInstruction }
