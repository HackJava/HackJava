package core

type L2D struct{ NoOperandsInstruction }

type L2F struct{ NoOperandsInstruction }

type L2I struct{ NoOperandsInstruction }
