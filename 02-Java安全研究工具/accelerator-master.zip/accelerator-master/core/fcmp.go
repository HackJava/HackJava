package core

type FCMPG struct{ NoOperandsInstruction }

type FCMPL struct{ NoOperandsInstruction }
