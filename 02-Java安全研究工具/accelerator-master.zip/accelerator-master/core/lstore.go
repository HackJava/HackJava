package core

type LSTORE struct{ Index8Instruction }

type LSTORE_0 struct{ NoOperandsInstruction }

type LSTORE_1 struct{ NoOperandsInstruction }

type LSTORE_2 struct{ NoOperandsInstruction }

type LSTORE_3 struct{ NoOperandsInstruction }
