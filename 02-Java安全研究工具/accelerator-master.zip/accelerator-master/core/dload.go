package core

type DLOAD struct{ Index8Instruction }

type DLOAD_0 struct{ NoOperandsInstruction }

type DLOAD_1 struct{ NoOperandsInstruction }

type DLOAD_2 struct{ NoOperandsInstruction }

type DLOAD_3 struct{ NoOperandsInstruction }
