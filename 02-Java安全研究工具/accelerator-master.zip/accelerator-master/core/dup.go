package core

type DUP struct{ NoOperandsInstruction }

type DUP_X1 struct{ NoOperandsInstruction }

type DUP_X2 struct{ NoOperandsInstruction }

type DUP2 struct{ NoOperandsInstruction }

type DUP2_X1 struct{ NoOperandsInstruction }

type DUP2_X2 struct{ NoOperandsInstruction }
