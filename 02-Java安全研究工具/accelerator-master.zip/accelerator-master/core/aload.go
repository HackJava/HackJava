package core

type ALOAD struct{ Index8Instruction }

type ALOAD_0 struct{ NoOperandsInstruction }

type ALOAD_1 struct{ NoOperandsInstruction }

type ALOAD_2 struct{ NoOperandsInstruction }

type ALOAD_3 struct{ NoOperandsInstruction }
