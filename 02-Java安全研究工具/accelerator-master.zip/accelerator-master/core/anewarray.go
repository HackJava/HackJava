package core

type ANEW_ARRAY struct{ Index16Instruction }
