package core

type IF_ACMPEQ struct{ BranchInstruction }

type IF_ACMPNE struct{ BranchInstruction }
