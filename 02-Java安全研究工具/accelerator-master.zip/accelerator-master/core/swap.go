package core

type SWAP struct{ NoOperandsInstruction }
