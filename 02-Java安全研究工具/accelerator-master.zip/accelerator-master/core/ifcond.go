package core

type IFEQ struct{ BranchInstruction }

type IFNE struct{ BranchInstruction }

type IFLT struct{ BranchInstruction }

type IFLE struct{ BranchInstruction }

type IFGT struct{ BranchInstruction }

type IFGE struct{ BranchInstruction }
