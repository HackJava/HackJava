package core

type DCMPG struct{ NoOperandsInstruction }

type DCMPL struct{ NoOperandsInstruction }
