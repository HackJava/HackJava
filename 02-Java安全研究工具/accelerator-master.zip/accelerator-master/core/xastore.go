package core

type AASTORE struct{ NoOperandsInstruction }

type BASTORE struct{ NoOperandsInstruction }

type CASTORE struct{ NoOperandsInstruction }

type DASTORE struct{ NoOperandsInstruction }

type FASTORE struct{ NoOperandsInstruction }

type IASTORE struct{ NoOperandsInstruction }

type LASTORE struct{ NoOperandsInstruction }

type SASTORE struct{ NoOperandsInstruction }
