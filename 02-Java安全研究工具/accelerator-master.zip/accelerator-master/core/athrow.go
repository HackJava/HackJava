package core

type ATHROW struct{ NoOperandsInstruction }
