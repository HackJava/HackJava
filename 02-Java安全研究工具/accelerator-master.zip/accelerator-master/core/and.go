package core

type IAND struct{ NoOperandsInstruction }

type LAND struct{ NoOperandsInstruction }
