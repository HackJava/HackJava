package core

type F2D struct{ NoOperandsInstruction }

type F2I struct{ NoOperandsInstruction }

type F2L struct{ NoOperandsInstruction }
