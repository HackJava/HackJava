package core

type FSTORE struct{ Index8Instruction }

type FSTORE_0 struct{ NoOperandsInstruction }

type FSTORE_1 struct{ NoOperandsInstruction }

type FSTORE_2 struct{ NoOperandsInstruction }

type FSTORE_3 struct{ NoOperandsInstruction }
