package core

type POP struct{ NoOperandsInstruction }

type POP2 struct{ NoOperandsInstruction }
