package core

type DDIV struct{ NoOperandsInstruction }

type FDIV struct{ NoOperandsInstruction }

type IDIV struct{ NoOperandsInstruction }

type LDIV struct{ NoOperandsInstruction }
