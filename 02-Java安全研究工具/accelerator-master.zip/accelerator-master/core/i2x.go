package core

type I2B struct{ NoOperandsInstruction }

type I2C struct{ NoOperandsInstruction }

type I2S struct{ NoOperandsInstruction }

type I2L struct{ NoOperandsInstruction }

type I2F struct{ NoOperandsInstruction }

type I2D struct{ NoOperandsInstruction }
