package core

type DADD struct{ NoOperandsInstruction }

type FADD struct{ NoOperandsInstruction }

type IADD struct{ NoOperandsInstruction }

type LADD struct{ NoOperandsInstruction }
