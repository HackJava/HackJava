package core

type DSUB struct{ NoOperandsInstruction }

type FSUB struct{ NoOperandsInstruction }

type ISUB struct{ NoOperandsInstruction }

type LSUB struct{ NoOperandsInstruction }
