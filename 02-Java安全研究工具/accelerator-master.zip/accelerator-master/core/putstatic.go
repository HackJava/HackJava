package core

type PUTSTATIC struct{ Index16Instruction }
