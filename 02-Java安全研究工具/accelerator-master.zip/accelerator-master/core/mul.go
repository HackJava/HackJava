package core

type DMUL struct{ NoOperandsInstruction }

type FMUL struct{ NoOperandsInstruction }

type IMUL struct{ NoOperandsInstruction }

type LMUL struct{ NoOperandsInstruction }
