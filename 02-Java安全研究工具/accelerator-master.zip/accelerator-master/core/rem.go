package core

type DREM struct{ NoOperandsInstruction }

type FREM struct{ NoOperandsInstruction }

type IREM struct{ NoOperandsInstruction }

type LREM struct{ NoOperandsInstruction }
