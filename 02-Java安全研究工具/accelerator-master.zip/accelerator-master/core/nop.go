package core

type NOP struct{ NoOperandsInstruction }
