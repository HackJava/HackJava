package core

type GOTO struct{ BranchInstruction }
