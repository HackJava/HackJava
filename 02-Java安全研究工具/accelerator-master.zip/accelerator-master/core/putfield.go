package core

type PUTFIELD struct{ Index16Instruction }
