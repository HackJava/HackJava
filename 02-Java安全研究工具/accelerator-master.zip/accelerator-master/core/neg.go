package core

type DNEG struct{ NoOperandsInstruction }

type FNEG struct{ NoOperandsInstruction }

type INEG struct{ NoOperandsInstruction }

type LNEG struct{ NoOperandsInstruction }
