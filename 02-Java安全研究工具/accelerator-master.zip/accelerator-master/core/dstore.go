package core

type DSTORE struct{ Index8Instruction }

type DSTORE_0 struct{ NoOperandsInstruction }

type DSTORE_1 struct{ NoOperandsInstruction }

type DSTORE_2 struct{ NoOperandsInstruction }

type DSTORE_3 struct{ NoOperandsInstruction }
