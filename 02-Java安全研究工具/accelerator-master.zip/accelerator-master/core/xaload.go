package core

type AALOAD struct{ NoOperandsInstruction }

type BALOAD struct{ NoOperandsInstruction }

type CALOAD struct{ NoOperandsInstruction }

type DALOAD struct{ NoOperandsInstruction }

type FALOAD struct{ NoOperandsInstruction }

type IALOAD struct{ NoOperandsInstruction }

type LALOAD struct{ NoOperandsInstruction }

type SALOAD struct{ NoOperandsInstruction }
