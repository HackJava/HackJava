package core

type ACONST_NULL struct{ NoOperandsInstruction }

type DCONST_0 struct{ NoOperandsInstruction }

type DCONST_1 struct{ NoOperandsInstruction }

type FCONST_0 struct{ NoOperandsInstruction }

type FCONST_1 struct{ NoOperandsInstruction }

type FCONST_2 struct{ NoOperandsInstruction }

type ICONST_M1 struct{ NoOperandsInstruction }

type ICONST_0 struct{ NoOperandsInstruction }

type ICONST_1 struct{ NoOperandsInstruction }

type ICONST_2 struct{ NoOperandsInstruction }

type ICONST_3 struct{ NoOperandsInstruction }

type ICONST_4 struct{ NoOperandsInstruction }

type ICONST_5 struct{ NoOperandsInstruction }

type LCONST_0 struct{ NoOperandsInstruction }

type LCONST_1 struct{ NoOperandsInstruction }
