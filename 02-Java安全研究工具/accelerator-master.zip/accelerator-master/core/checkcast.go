package core

type CHECK_CAST struct{ Index16Instruction }
