package core

type INSTANCEOF struct{ Index16Instruction }
