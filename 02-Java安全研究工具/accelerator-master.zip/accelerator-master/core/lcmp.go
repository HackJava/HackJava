package core

type LCMP struct{ NoOperandsInstruction }
