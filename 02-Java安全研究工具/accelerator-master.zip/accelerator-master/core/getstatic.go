package core

type GET_STATIC struct{ Index16Instruction }
