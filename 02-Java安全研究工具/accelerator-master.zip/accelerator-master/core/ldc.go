package core

type LDC struct{ Index8Instruction }

type LDC_W struct{ Index16Instruction }

type LDC2_W struct{ Index16Instruction }
