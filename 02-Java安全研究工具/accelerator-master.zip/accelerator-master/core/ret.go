package core

type RET struct{ Index8Instruction }
