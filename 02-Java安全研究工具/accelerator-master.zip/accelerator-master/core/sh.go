package core

type ISHL struct{ NoOperandsInstruction }

type ISHR struct{ NoOperandsInstruction }

type IUSHR struct{ NoOperandsInstruction }

type LSHL struct{ NoOperandsInstruction }

type LSHR struct{ NoOperandsInstruction }

type LUSHR struct{ NoOperandsInstruction }
