package core

type IF_ICMPEQ struct{ BranchInstruction }

type IF_ICMPNE struct{ BranchInstruction }

type IF_ICMPLT struct{ BranchInstruction }

type IF_ICMPLE struct{ BranchInstruction }

type IF_ICMPGT struct{ BranchInstruction }

type IF_ICMPGE struct{ BranchInstruction }
